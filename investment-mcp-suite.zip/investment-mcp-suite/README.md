# investment-mcp-suite

okdsgr の個人投資作業を MCP（Model Context Protocol）と連携させて運用するための統合作業スペース。
Godot ゲーム開発の `mvp-XX` 系プロジェクトとはスコープを明確に分離するために独立リポジトリとして設置。

## 構成

```
investment-mcp-suite/
├── docs/                           # 運用ドキュメント
│   ├── operation-rules.md          # 投資運用ルール（ストップロス・利確・推奨指値）
│   ├── handoff-template.md         # チャット引き継ぎテンプレート
│   ├── mcp-architecture.md         # 使用MCP一覧と役割分担
│   └── mcp-redundancy.md           # MCP冗長化の設計と障害時の切り替え
├── reports/                        # 日次・週次レポート
│   ├── daily-report-template.md    # 朝レポートテンプレート
│   └── YYYY-MM-DD.md               # 各日のレポート（手動配置）
├── scripts/                        # 補助スクリプト（GDScript / Bash / その他）
│   └── .gitkeep
└── README.md
```

## 関連リポジトリ

| リポジトリ | 役割 |
|---|---|
| [okdsgr/yfinance-mcp](https://github.com/okdsgr/yfinance-mcp) | Yahoo Finance を叩く自作 MCP サーバー（quote/batch/historical） |
| 上記とは別に外部 MCP として利用 | TradingView MCP（@ivotoby/openapi-mcp-server 経由）|

## 使用環境

- **Windows デスクトップ**（オフィス・メイン）: `C:\Users\s-okada\mcp-servers\investment-mcp-suite\`
- **Mac ラップトップ**（自宅・外出先）: `~/mcp-servers/investment-mcp-suite/`
- **Claude Desktop** からの MCP 連携、Godot Editor 経由のファイル操作自動化

## チャット運用

このスペースに関連する Claude チャットの命名規則: **「投資対談XX」**（XX は連番）
Godot 開発の「Godot-XXX」チャットとは別系統で進行する。

## ライセンス

個人作業のため非公開（Private）。
