# MCP 冗長化設計

A-4 の成果物。価格取得 MCP の二系統運用ポリシー。

## 基本方針

**単一障害点を作らない。** 主系統が停止した場合、即座に代替系統で作業を継続できる体制。

## 系統構成

### 価格取得 MCP（株価データソース）

| 系統 | サーバー | データソース | 用途 |
|---|---|---|---|
| **1次** | yfinance-mcp（自作） | Yahoo Finance（yahoo-finance2 v3 経由） | 通常運用 |
| **2次** | tradingview-mcp | TradingView（RapidAPI 経由） | 1次が落ちた時の代替 + 主要銘柄のクロスチェック |

### なぜ2系統か

- Yahoo Finance API の認証フロー（crumb cookie）変更で `@mokemokechicken版` が停止した実績
- TradingView も RapidAPI 経由のため、契約・課金で停止しうる
- どちらも単独だと運用継続のリスク

## 障害切り替え判断

### yfinance（1次）が応答しない場合

#### 症状
- `get_quote` が `❌ get_quote 失敗 [NVDA]: ...` と返す
- `batch_get_quotes` の summary で `failed > 0`

#### 切り替え手順
1. tradingview-mcp で同じ銘柄を取得（`tradingview:get-quote` または `batch-get-quote`）
2. 価格が取れたら 2次系統で継続
3. yfinance 側の調査:
   - `yahoo-finance2` を最新版に更新: `cd <パス> && npm update yahoo-finance2 && npm run build`
   - Claude Desktop 再起動
4. それでもダメなら、`@mokemokechicken` 等の代替実装に一時切り替え（参考: 過去のセッションで実績あり）

### tradingview（2次）が応答しない場合

#### 症状
- `tradingview:get-quote` がエラーを返す
- RapidAPI の rate limit 超過、または API キー無効

#### 切り替え手順
1. yfinance-mcp に一本化（クロスチェックは一時的に省略）
2. RapidAPI ダッシュボードでステータス確認
3. キーローテーション or プラン変更が必要なら別途対応

## クロスチェック運用

主要保有銘柄（NVDA, GLW, IREN, LITE, GLDM など）については、両系統で価格を取得して以下を確認:

- 価格の整合性: ±0.5% 以内（小数点精度の差を含む）
- 出来高の整合性: 同じ日のデータなら一致するはず
- マーケットステート: 整合（PRE/REGULAR/POSTPOST/CLOSED）

差分があった場合は、yfinance を信頼（リアルタイム性が高い）。ただし、TradingView の方が遅延データを返している可能性もあるため要確認。

## バックアップ

### Claude Desktop 設定ファイル

`%APPDATA%\Claude\claude_desktop_config.json` を編集する前に必ずスナップショット:

```cmd
copy %APPDATA%\Claude\claude_desktop_config.json %USERPROFILE%\Documents\claude_config_snapshot_YYYYMMDD.json
```

復旧コマンド:
```cmd
copy /Y %USERPROFILE%\Documents\claude_config_snapshot_YYYYMMDD.json %APPDATA%\Claude\claude_desktop_config.json
```

### yfinance-mcp 自体

- GitHub `okdsgr/yfinance-mcp` がプライマリ
- ローカルは Win/Mac の2台にミラー
- `npm install` の結果（node_modules）は各端末で再生成

## 環境チェック

新しいチャットを始めた時の動作確認手順:

```
1. yfinance MCPで NVDA のクオートを取得して
   → 価格・出来高・PER が JSON で返る
2. TradingView MCP で NVDA のクオートを取得して
   → 価格情報が返る
3. 両者の価格が ±0.5% 以内で一致することを確認
```

NG なら 1次・2次のどちらが落ちているかを切り分け、上記の手順で復旧。
