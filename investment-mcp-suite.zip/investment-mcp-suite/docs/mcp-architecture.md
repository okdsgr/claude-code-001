# MCP アーキテクチャ

okdsgr の Claude Desktop に接続している MCP サーバー一覧と各々の役割。

## 接続MCPサーバー（claude_desktop_config.json）

| サーバー名 | 種別 | 接続方式 | 主用途 |
|---|---|---|---|
| `yfinance` | 自作 | node + stdio | 株価・ヒストリカル取得（1次） |
| `tradingview` | サードパーティ | npx @ivotoby/openapi-mcp-server + RapidAPI | 株価・チャート・ニュース（2次） |
| `gemini` | サードパーティ | npx @houtini/gemini-mcp | 画像/動画生成、汎用LLM補助 |
| `godot` | サードパーティ | node + stdio (port 9080) | Godot Editor 操作 + Windows ファイルシステムアクセス |

設定ファイル: `%APPDATA%\Claude\claude_desktop_config.json` (Windows) / `~/Library/Application Support/Claude/claude_desktop_config.json` (Mac)

## クラウドMCP（Claude.ai 側で設定済み）

| サーバー名 | 用途 |
|---|---|
| Box | PDF 等資料の読み込み |
| Slack | チームコミュニケーション（未使用） |
| Atlassian Rovo | Jira/Confluence（未使用） |
| Notion | ドキュメント管理 |
| Google Calendar / Drive / Gmail | スケジュール、ファイル、メール |
| n8n | ワークフロー自動化 |

## yfinance-mcp 詳細

### バージョン
- v0.1.0（2026-05-11 初版）
- yahoo-finance2 v3.14.0 ベース
- Node.js >= 18

### 提供ツール

| ツール | 用途 |
|---|---|
| `get_quote` | 単一銘柄クオート（価格・出来高・PER・52週高安・時間外価格） |
| `batch_get_quotes` | 複数銘柄（最大20件）一括取得 |
| `get_historical` | ヒストリカルOHLCV（1d〜maxまで） |

### 採用理由

- `@szemeng76/yfinance-mcp` は Zod バージョン不整合で動作不良
- `@mokemokechicken/yfinance-mcp-server` は Yahoo API レスポンス変化に追従できず空データを返す
- 自前実装で `yahoo-finance2` を直接コントロール、API変化への追従が早い
- 日本株 (`7203.T` 形式)、米株、ETF、暗号通貨、為替に対応

## 関連設定

- リポジトリ: [okdsgr/yfinance-mcp](https://github.com/okdsgr/yfinance-mcp)
- ローカルパス（Win）: `C:\Users\s-okada\mcp-servers\yfinance-mcp\`
- ローカルパス（Mac）: `~/mcp-servers/yfinance-mcp/`
- 実行コマンド: `node <パス>\build\index.js`
